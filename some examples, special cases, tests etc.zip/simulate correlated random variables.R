library(MASS)

C=matrix(c(1,0.4,-0.3,0.4,1,0.2,-0.3,0.2,1),nrow=3,ncol=3) # correlation matrix
A=chol(C) # Cholesky decomposition

z=mvrnorm(1000,mu=rep(0,3),Sigma=diag(3)) # multivariate 0-1 normal random numbers
x=z%*%A # x has (roughly) correlation C 

xs=scale(x) # force each column to mean=0 and sd=1

MEAN=c(2,5,-3) # target mean
SD=c(1.5,3,0.4) # target sd
y=t(t(xs)*SD+MEAN) # y has exactly mean=MEAN and sd=SD
