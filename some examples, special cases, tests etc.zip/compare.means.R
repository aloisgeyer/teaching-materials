c.base=30000
c.exper=1000
c.skill=10000

n.skill.1=25
n.skill.0=75

experience.avg=30
experience.sd=5
experience=experience.avg+experience.sd*c(rnorm(n.skill.1),rnorm(n.skill.0)) 

skill=c(rep(1,n.skill.1),rep(0,n.skill.0))
noise=rnorm(n.skill.1+n.skill.0)*1

experience=experience-10*skill

salary=c.base+c.exper*experience+c.skill*skill+noise

df=data.frame(cbind(salary,experience, skill,noise))

lm=lm(salary~skill,df)
summary(lm)

anova=aov(salary~skill)
summary(anova)

lm=lm(salary~experience+skill,df)
summary(lm)

