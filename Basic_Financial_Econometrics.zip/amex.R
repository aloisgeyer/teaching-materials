# amex.R
library("dynlm")

amex <- read.csv("amex.txt",stringsAsFactors = TRUE, header=FALSE, col.names="amex")

amex=ts(amex, start=c(1993,8,2), frequency=365)

plot(amex)

acf(amex)

urt=dynlm(amex~L(amex))
summary(urt)

urt=dynlm(diff(amex)~L(amex))
summary(urt)

acf(diff(amex))
pacf(diff(amex))

urt=dynlm(diff(amex)~L(amex)+L(diff(amex)))
summary(urt)

library(tseries)
adf.test(amex)
adf.test(amex,k=1)

kpss.test(amex)