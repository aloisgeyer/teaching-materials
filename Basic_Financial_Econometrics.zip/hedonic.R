# hedonic.R
# illustrate interactions
library(interactions)

data <- read.csv("hedonic.csv",sep=";",stringsAsFactors = FALSE)

base=lm(PRICE~BDRMS+SQRFT+STYLE,data)
summary(base)

interact=lm(PRICE~BDRMS+SQRFT+STYLE+BDRMS*SQRFT,data)
summary(interact)

# The interaction implies varying slopes w.r.t to one of the two regressors 
# depending on the level of the other regressor in the interaction
# For example: the slope w.r.t BDRMS even changes the sign 
# interpretations: additional bedrooms in small(er) houses are less "attractive" than in larg(er) houses
interact_plot(interact,pred=BDRMS,modx=SQRFT) 
interact_plot(interact,pred=BDRMS,modx=SQRFT,modx.values=c(1500,2000,2500)) # check for specific values of SQFT 

# Compare coefficients of base model to stand-alone coefficients of interaction model
# For a meaningful comparison it is necessary to set the levels of the regressors involved in the interaction to meaningful values. 
# e.g. using the mean of BDRMS and SQRFT

mean(data[,"BDRMS"])
mean(data[,"SQRFT"])
          
cat(interact$coefficients["BDRMS"]+interact$coefficients["BDRMS:SQRFT"]*mean(data[,"SQRFT"]),
    interact$coefficients["SQRFT"]+interact$coefficients["BDRMS:SQRFT"]*mean(data[,"BDRMS"]))

# The "implied" slope of 6.6863 for BDRMS is rather close to the stand-alone coefficient 12.4875 from the base model.
# The "implied" slope of 0.11717 for SQRFT is very close to the stand-alone coefficient 0.1298 from the base model.
# Hence a direct comparison of stand-alone coefficients in an interaction model with the corresponding slopes in a regression 
# without an interaction does not make sense unless we fix the levels of the interacted regressors to meaningful values. 
# Note: this procedure makes comparisons more meaningful. Since the base model suffers from an omitted variable bias 
# compared to the interaction model, there will always be and additional effect from that side.

# Testing for significance:
# Whether or not there is a significant interaction effect can be directly tested on the basis of the 
# coefficient of the interaction term interact$coefficients["BDRMS:SQRFT"]
# However, given the arguments about comparability illustrated above it becomes obvious that the stand-alone coefficients 
# in an interaction model cannot be simply tested for significance. Since the interaction model does not imply a single slope
# w.r.t. to on e of the two regressors but rather a range of slopes (depending on the level of the other regressor), a  test of 
# H0: slope=0 is not possible on the basis of the t-statistics or p-values of stand-alone coefficients.
# The Johnson-Neyman intervals indicate for which values of SQRFT the slope w.r.t BDRMS (for example) is significant, thereby 
# acknowledging that p-values depend on levels of the regressors in the interaction term.

johnson_neyman(interact,pred=BDRMS,modx=SQRFT)
johnson_neyman(interact,pred=SQRFT,modx=BDRMS) 
