library(survival)

data("lung")

# remove rows with at least one missing observation
isna=rowSums((is.na(lung)))
lung=lung[isna==0,]

# censoring is controlled via status: status 1=censored, 2=dead

surv.expon <- survreg(Surv(time, status)~1,dist="exponential",data=lung)
summary(surv.expon)

surv.weibull <- survreg(Surv(time, status)~1,dist="weibull",scale=0, data=lung)
summary(surv.weibull)

surv.reg.expon <- survreg(Surv(time, status)~age+sex+ph.ecog+ph.karno+pat.karno+meal.cal+wt.loss,dist="exponential",data=lung)
summary(surv.reg.expon)

surv.reg.weibull <- survreg(Surv(time, status)~age+sex+ph.ecog+ph.karno+pat.karno+meal.cal+wt.loss,dist="weibull",scale=0, data=lung)
summary(surv.reg.weibull)

cox.reg <- coxph(Surv(time, status)~age+sex+ph.ecog+ph.karno+pat.karno+meal.cal+wt.loss, data=lung)
summary(cox.reg)
cox.reg$loglik