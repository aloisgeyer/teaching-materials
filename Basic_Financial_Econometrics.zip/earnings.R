# earnings.R
library(lmtest)

data <- read.csv("earnings.txt",sep="",stringsAsFactors = FALSE)

# Example 14:

reg=lm(log(EARNINGS)~DURATION+SCHOOLING,data)
summary(reg)

data[,"e"]=residuals(reg)
plot(data$DURATION,data$e)

bptest(reg)

white.test.aux.reg=lm(e^2~DURATION+I(DURATION^2)+SCHOOLING+I(SCHOOLING^2),data)
summary(white.test.aux.reg)
nrow(data)*summary(white.test.aux.reg)$r.squared

# Example 17:
reg.wls1=lm(log(EARNINGS)~DURATION+SCHOOLING,data,weights=I(1/DURATION^2))
summary(reg.wls1)

# by hand
data[,"EARNINGS.w"]=log(data[,"EARNINGS"])/data[,"DURATION"]
data[,"DURATION.w"]=1/data[,"DURATION"]
data[,"SCHOOLING.w"]=data[,"SCHOOLING"]/data[,"DURATION"]

reg.wls2=lm(EARNINGS.w~DURATION.w+SCHOOLING.w,data)
summary(reg.wls2)

data[,"e.wls2"]=residuals(reg.wls2)
plot(data$DURATION,data$e.wls2)