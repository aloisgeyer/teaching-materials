# ftse.R

ftse <- read.csv("ftse.txt",sep="",stringsAsFactors = TRUE)

x=ts(ftse[,2], start=c(1965,1), end=c(1990,12), frequency=12)
plot(x)

y=diff(log(x))
plot(y)
mean(y);mean(y)*12
sd(y);sd(y)*sqrt(12)

r=exp(y)-1
mean(r)
exp(mean(y)+0.5*sd(y)^2)-1

acf(y)
pacf(y)

acf(abs(y))
pacf(abs(y))

arma11=arima(y,order = c(1,0,1))
print(arma11)
tsdiag(arma11)
arma11$coef
sqrt(diag(arma11$var.coef))

e=residuals(arma11)
yhat=y-e
plot(y)
points(yhat,col="red")

arma22=arima(y,order = c(2,0,2))
tsdiag(arma22)
print(arma22)

e=residuals(arma22)
yhat=y-e
plot(y)
points(yhat,col="red")
arma22$coef
sqrt(diag(arma22$var.coef))

library(forecast)
arma22=Arima(y,order = c(2,0,2))
autoplot(arma22)
roots=autoplot(arma22)[1]
roots
checkresiduals(arma22)

library(tseries)
g11=garch(y)
summary(g11)
e=g11$residuals
plot(y)
plot(e)

library(fGarch)
gf=garchFit(~arma(1,0)+garch(1,1),y)
summary(gf)
plot(gf)
