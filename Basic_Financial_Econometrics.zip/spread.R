# spread.R

spread <- read.csv("spread.csv",sep=",",stringsAsFactors = TRUE)

spread=ts(spread[,2], start=c(1952,1), end=c(1988,4), frequency=4)

acf(spread)
pacf(spread)
ar1=arima(spread,order = c(1,0,0))

e=residuals(ar1)
yhat=spread-e

tsdiag(ar1)

library(tseries)
adf.test(spread)
adf.test(spread,k=0)

kpss.test(spread)