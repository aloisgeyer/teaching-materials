library(sampleSelection)
library(AER)

#### Greene 7th: Example 19.11, p.918  ####
# https://cran.r-project.org/web/packages/sampleSelection/vignettes/selection.pdf 
# same as: Greene, 5th (2003): Example 22.8, page 786

data( "Mroz87")
Mroz87$kids <- ( Mroz87$kids5 + Mroz87$kids618 > 0 )
Mroz87$lwage=log(Mroz87$wage)
Mroz87$expersq=Mroz87$exper^2
Mroz87$agesq=Mroz87$age^2

GreeneTS <- selection( lfp ~ age + agesq + faminc + kids + educ, # lfp ... labor force participation
                       wage ~ exper + expersq + educ + city,
                       data = Mroz87, method = "2step" )
summary(GreeneTS)

GreeneML <- selection( lfp ~ age + agesq + faminc + kids + educ,
                       wage ~ exper + expersq + educ + city, 
                       data = Mroz87, maxMethod = "BHHH", iterlim = 500 )
summary(GreeneML)

# selection and outcome with the same regressors; usually not recommended!
Greene <- selection( lfp ~ exper + expersq + educ + city,
                     wage ~ exper + expersq + educ + city,
                     data = Mroz87, method = "2step" )
summary(Greene)

# BY HAND
probit=glm(lfp ~ age + agesq + faminc + kids + educ,
           data = Mroz87, family=binomial(link="probit"))

# compute inverse Mills ratio
x=model.matrix(probit)
b=probit$coefficients
fit=x%*%b
Mroz87$lambda=dnorm(fit)/pnorm(fit)

sub.mroz=subset(Mroz87,wage>0)

snd.stage=lm(wage ~ exper + expersq + educ + city + lambda, data=sub.mroz)
summary(snd.stage)

# ignore sample selection problem; LS only
ignore=lm(wage ~ exper + expersq + educ + city, data=sub.mroz)
summary(ignore)

#### Soederbom Lecture 15 "Two empirical illustrations of the Heckit model" ####
# 2.2 Earnings regressions for females in the US
# treat sample selection and endogeneity
# http://www.soderbom.net/lecture15final.pdf  
# also mentioned in Wooldridge (2002), Example 17.7 (Education Endogenous and Sample Selection)

sub.mroz=subset(Mroz87,wage>0)

ols=lm(lwage~educ+exper+expersq,data=sub.mroz)
summary(ols)

select=glm(lfp~nwifeinc+educ+exper+expersq+age+kids5+kids618,data=Mroz87,family = binomial(link="probit"))
summary(select)

x=model.matrix(select)
b=select$coefficients
fit=x%*%b
Mroz87$inv.MR=dnorm(fit)/pnorm(fit)

sub.mroz=subset(Mroz87,wage>0)

second.stage=lm(lwage~educ+exper+expersq+inv.MR,data=sub.mroz)
summary(second.stage)

# now account for endogenous education 
# remove educ and add instruments  
select2=glm(lfp~nwifeinc+exper+expersq+age+kids5+kids618+motheduc+fatheduc+huseduc,data=Mroz87,family = binomial(link="probit"))
summary(select2)

x=model.matrix(select2)
b=select2$coefficients
fit=x%*%b
Mroz87$imr=dnorm(fit)/pnorm(fit)

sub.mroz=subset(Mroz87,wage>0)

ivreg=ivreg(lwage~educ+exper+expersq+imr | 
              nwifeinc+exper+expersq+age+kids5+kids618+motheduc+fatheduc+huseduc+imr,data=sub.mroz)
summary(ivreg)
  
#### 5.2. Cameron and Trivedi (2005): Section 16.6, page 553 ####

data( "RandHIE" )

subsample <- RandHIE$year == 2 & !is.na( RandHIE$educdec )

selectEq <- binexp ~ logc + idp + lpi + fmde + physlm + disea +
  hlthg + hlthf + hlthp + linc + lfam + educdec + xage + female +
  child + fchild + black

outcomeEq <- lnmeddol ~ logc + idp + lpi + fmde + physlm + disea +
  hlthg + hlthf + hlthp + linc + lfam + educdec + xage + female +
  child + fchild + black

rhieTS <- selection( selectEq, outcomeEq, data = RandHIE[ subsample, ],
                     method = "2step" )

rhieML <- selection( selectEq, outcomeEq, data = RandHIE[ subsample, ] )

summary(rhieTS)
summary(rhieML)
