# long.R

library(dplyr)
library(AER)

long <- read.csv("long.txt",sep="",stringsAsFactors = FALSE)

long=long %>% mutate(log.DAXW=log(DAXW),
                     y=log.DAXW-dplyr::lag(log.DAXW,n=1),
                     y.52=log.DAXW-dplyr::lag(log.DAXW,n=52),
                     d_53=dplyr::lag(DYD,n=53),
                     s_53=dplyr::lag(SPR,n=53),
                     r_53=dplyr::lag(REAL,n=53),
                     g_53=dplyr::lag(PGR,n=53)
                     ) %>% na.omit

lh.reg=lm(y.52~d_53+s_53+r_53+g_53,data=long)
summary(lh.reg)
coeftest(lh.reg, vcov = NeweyWest(lh.reg))
