# uirp.R 
# file 'forward2c.dat" downloaded from https://www.wiley.com//legacy/wileychi/verbeek2ed/datasets.html 
# tests on uncovered interest rate parity

library(dplyr)

fw=read.csv(file="forward2c.dat",sep="")

fw=fw%>%mutate(s.USEUR=log(EXUSEUR),
               f.USEUR=log(F1USEUR),
               ds.USEUR=s.USEUR-dplyr::lag(s.USEUR,n=1),
               fp.USEUR=dplyr::lag(f.USEUR,n=1)-dplyr::lag(s.USEUR,n=1)
               )
fw=na.omit(fw)

reg.useur=lm(ds.USEUR~fp.USEUR,data=fw)
summary(reg.useur)

# Residual standard error "by hand"
e=reg.useur$residuals
df=reg.useur$df.residual
se.reg.useur=sqrt(sum(e^2)/df)

# standard errors of coefficients, t-stats and p-values by hand
coef.reg.useur=reg.useur$coefficients
se.coef.reg.useur=sqrt(diag(vcov(reg.useur)))
t.coef.reg.useur=coef.reg.useur/se.coef.reg.useur
pvalue.coef.reg.useur=2*(1-pt(abs(t.coef.reg.useur),df=df))

# test H0: beta1=1
t.beta1=(coef.reg.useur[2]-1)/se.coef.reg.useur[2]
pvalue.beta1=2*(1-pt(abs(t.beta1),df=df))

# joint test by hand
R=as.matrix(diag(2))
delta=as.vector(c(0,1))
d=R%*%coef.reg.useur
X=model.matrix(reg.useur)

W=t(d-delta)%*%solve((se.reg.useur^2)*(R%*%solve(t(X)%*%X)%*%t(R)))%*%(d-delta)
pvalue.W=1-pchisq(W,2)

# F-test by hand
Rsq.u=summary(reg.useur)$r.squared
e.restricted=fw[,"ds.USEUR"]-fw[,"fp.USEUR"]
sse.r=sum(e.restricted^2)
ssy=sum((fw[,"ds.USEUR"]-mean(fw[,"ds.USEUR"]))^2)
       
Rsq.r=1-sse.r/ssy
F=df*(Rsq.u-Rsq.r)/(2*(1-Rsq.u))
pvalue.F=1-pf(F,2,df)