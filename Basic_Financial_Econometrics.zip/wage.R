# wage.R
library(AER)
library(MASS)

wage <- read.csv("wage.csv",header=T,sep=";") 
wage$logWAGE=log(wage$WAGE)

ols=lm(logWAGE~EDUC+EXPER+EXPERSQ+ETHN+MARRIED,data=wage)
summary(ols)

iv = ivreg(logWAGE~EDUC+EXPER+EXPERSQ+ETHN+MARRIED | EXPER+EXPERSQ+ETHN+MARRIED+NEAR,data=wage)
summary(iv)

first = lm(EDUC~EXPER+EXPERSQ+ETHN+MARRIED+NEAR,data=wage)
summary(first)
wage$EDUC.fitted=fitted(first)
wage$v=residuals(first)

second = lm(logWAGE~EDUC.fitted+EXPER+EXPERSQ+ETHN+MARRIED,data=wage)
summary(second)

endo.test = lm(logWAGE~EDUC+EXPER+EXPERSQ+ETHN+MARRIED+v,data=wage)
summary(endo.test)

# Hausman test
d=iv$coefficients-ols$coefficients
X=model.matrix(ols)
X.hat=model.matrix(second)

XpX.inv=solve(t(X)%*%X)
XhpXh.inv=solve(t(X.hat)%*%X.hat)

h=ginv(XhpXh.inv-XpX.inv) # store intermediate results in h
H=(t(d)%*%h%*%d)/(iv$sigma^2)
cat("p-value Hausman test:",1-pchisq(H,1),"\n")
