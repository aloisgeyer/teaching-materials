# truncation.R
library(MASS)

n=1000
a=0.2 # threshold; y is only observed if z>a

Rho=matrix(c(1,0.4,0.4,1),nrow=2,ncol=2) # correlation matrix
C=chol(Rho) # Cholesky decomposition

z=mvrnorm(n,mu=rep(0,2),Sigma=diag(2)) # bivariate 0-1 normal random numbers
x=z%*%C # x has (roughly) correlation C 

xs=scale(x) # force each column to mean=0 and sd=1

MEAN=c(2,0) # target mean; first mean of y; second mean of z
SD=c(1.5,1) # target sd
X=t(t(xs)*SD+MEAN) # y has exactly mean=MEAN and sd=SD

y.obs=X[(X[,2]>a),1]

alpha.z=(a-MEAN[2])/SD[2]
lambda=dnorm(alpha.z)/(1-pnorm(alpha.z))
cat("expectation conditional on truncation:","\n",MEAN[1]+Rho[1,2]*SD[1]*lambda,"\n")
mean(y.obs)
sd(y.obs)
