# dummy.variables.R
# GENERAL REMARK: I do not include other regressors on purpose to keep things simple
# This leads to an omitted variable bias which I'm willing to accept for the sake of simplicity.
# I strongly recommend to add further (potentially relevant) regressors!

train <- read.csv("train_500.csv",stringsAsFactors = FALSE)

# add some variables
train[,"RemodAdd_YN"]=as.integer(train[,"YearBuilt"] != train[,"YearRemodAdd"])
train[,"Age"]=train[,"YrSold"] - train[,"YearBuilt"] # age when sold!
train[,"Years_since_Built_or_Remod"]=train[,"YrSold"] - train[,"YearRemodAdd"]

library(dplyr)
train %>% group_by(RemodAdd_YN) %>% summarize(mean(SalePrice))

# RemodAdd_YN `mean(SalePrice)`
#           <int>             <dbl>
#   1           0           176198. # average of RemodAdd_YN=0
#   2           1           165372. # average of RemodAdd_YN=1

# a regression with a dummy variable (here. RemodAdd_YN) computes/estimates averages for groups
remod=lm(data=train,SalePrice~RemodAdd_YN)
summary(remod) 

# Estimate Std. Error t value Pr(>|t|)    
# (Intercept)   176198       4197  41.981   <2e-16 *** # average of RemodAdd_YN=0
# RemodAdd_YN   -10827       6243  -1.734   0.0835 .   # difference between avg of RemodAdd_YN=0 and RemodAdd_YN=1

# treat OverallQual as a metric/cardinal measure 
qual.metric=lm(data=train,SalePrice~OverallQual)
summary(qual.metric)

train[,"fit.metric"]=qual.metric$fitted.values
plot(train[,"Age"],train[,"SalePrice"])
points(train[,"Age"],train[,"fit.metric"],col="red")
  
# Estimate Std. Error t value Pr(>|t|)    
# (Intercept)   -76572       8722  -8.779   <2e-16 ***
# OverallQual    40890       1404  29.115   <2e-16 ***
# 40890 is the expected price impact of moving up one notch on the quality scale
# assuming that the ordinal scale underlying OverallQual can be treated as a metric scale

# treat OverallQual as a categorical measure; requires converting it to (several) dummy variables
train[,"qual.cat"]=as.factor(train[,"OverallQual"])
qual.cat=lm(data=train,SalePrice~qual.cat)
summary(qual.cat)

#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)    60000      40360   1.487 0.137753    
# qual.cat3      25500      46603   0.547 0.584509    
# qual.cat4      41631      40806   1.020 0.308119    
# qual.cat5      69514      40496   1.717 0.086685 .  
# qual.cat6      96688      40527   2.386 0.017423 *  
# qual.cat7     139372      40546   3.437 0.000637 ***
# qual.cat8     209484      40706   5.146 3.85e-07 ***
# qual.cat9     282124      42330   6.665 7.13e-11 ***
# qual.cat10    255464      43146   5.921 6.02e-09 ***

# 60000 is the average price of houses for which OverallQual=2 (the reference category)
# 25500 is the average price difference between houses for which OverallQual=2 and OverallQual=3 
# 41631 is the average price difference between houses for which OverallQual=2 and OverallQual=4
# ...
# 255464 is the average price difference between houses for which OverallQual=2 and OverallQual=10

train[,"fit.cat"]=qual.cat$fitted.values
plot(train[,"Age"],train[,"SalePrice"])
points(train[,"Age"],train[,"fit.cat"],col="red")

# test quality categories for joint significance
constraints=paste0("qual.cat",(3:10),"=0")
car::linearHypothesis(qual.cat,constraints)

# Hypothesis:
# qual.cat3 = 0
# qual.cat4 = 0
# qual.cat5 = 0
# qual.cat6 = 0
# qual.cat7 = 0
# qual.cat8 = 0
# qual.cat9 = 0
# qual.cat10 = 0
# 
# Model 1: restricted model
# Model 2: SalePrice ~ qual.cat
#
# Res.Df        RSS Df  Sum of Sq     F    Pr(>F)    
# 1    499 2.4182e+12                                  
# 2    491 7.9979e+11  8 1.6184e+12 124.2 < 2.2e-16 ***

# change reference category and test again
train<-within(train,qual.cat<-relevel(qual.cat,ref=9))
qual.cat.alt.ref=lm(data=train,SalePrice~qual.cat)
summary(qual.cat.alt.ref)
constraints=paste0("qual.cat",(2:9),"=0")
car::linearHypothesis(qual.cat.alt.ref,constraints)

# Hypothesis:
# qual.cat2 = 0
# qual.cat3 = 0
# qual.cat4 = 0
# qual.cat5 = 0
# qual.cat6 = 0
# qual.cat7 = 0
# qual.cat8 = 0
# qual.cat9 = 0
# 
# Model 1: restricted model
# Model 2: SalePrice ~ qual.cat
# 
# Res.Df        RSS Df  Sum of Sq     F    Pr(>F)    
# 1    499 2.4182e+12                                  
# 2    491 7.9979e+11  8 1.6184e+12 124.2 < 2.2e-16 ***

# check whether price impact from one category to the next is similar
diff(coefficients(qual.cat)[2:9])
# qual.cat4  qual.cat5  qual.cat6  qual.cat7  qual.cat8  qual.cat9 qual.cat10 
#  16131.29   27883.15   27173.17   42684.63   70111.66   72639.60  -26659.21
# these numbers indicate that the replacing the ordinal scale as a metric scale is problematic
# in other words: converting each category to a dummy (treat it as a factor in R) accounts for
# the non-metric nature of OverallQual (accounts for nonlinearities in the link between price and quality)
# NOTE: these conclusions may change after adding additional regressors (recommended!)

# treat OverallQual as a categorical measure, but this time estimate the difference between quality levels directly!
# construct dummy variables
h=matrix(rep(2:10),nrow=nrow(train),ncol=9,byrow=T)
d=(h<=train[,"OverallQual"])*1
for (i in 3:10){train[,paste0("qual.cat.",i)]=d[,i-1]}

regnames=paste0("qual.cat.",3:10)
frml=as.formula(paste0("SalePrice~",paste0(regnames,collapse="+")))
qual.cat.inc=lm(data=train,frml)
summary(qual.cat.inc)

# Estimate Std. Error t value Pr(>|t|)    
# (Intercept)    60000      40360   1.487    0.138    
# qual.cat.3     25500      46603   0.547    0.585    
# qual.cat.4     16131      24066   0.670    0.503    
# qual.cat.5     27883       6870   4.058 5.75e-05 ***
# qual.cat.6     27173       4958   5.481 6.78e-08 ***
# qual.cat.7     42685       5353   7.974 1.09e-14 ***
# qual.cat.8     70112       6570  10.671  < 2e-16 ***
# qual.cat.9     72640      13819   5.256 2.20e-07 ***
# qual.cat.10   -26659      19889  -1.340    0.181 
# now we get coefficients which measure/estimate directly the price impact compare to the previous quality level
# accordingly, the significance tests here make more sense than those from model 'qual.cat'

# test whether the coefficients associated with the dummies from regression qual.cat.inc are identical 
# construct matrix R (see lecture notes p.14)
# we impose 7 restrictions: 
# coef.cat.3-coef.cat.4=0, coef.cat.3-coef.cat.5=0, coef.cat.3-coef.cat.6=0, ...
R=matrix(0,nrow=7,ncol=9)
R[1:7,2]=1
R[1,3]=-1
R[2,4]=-1
R[3,5]=-1
R[4,6]=-1
R[5,7]=-1
R[6,8]=-1
R[7,9]=-1

cfs=qual.cat.inc$coefficients
d=R%*%cfs
# if price impact from one categrory to the next is identical, the elements of d should be jointly zero
d
# [1,]   9368.711
# [2,]  -2383.150
# [3,]  -1673.169
# [4,] -17184.632
# [5,] -44611.656
# [6,] -47139.603
# [7,]  52159.214

# compute Wald test statistic W (eqn 7, p.14)
# note: delta is 0 (null hypothesis)

se2=(summary(qual.cat.inc)$sigma)^2
X=model.matrix(qual.cat.inc)
XtXi=solve(t(X)%*%X)
temp=solve(se2*R%*%XtXi%*%t(R))
W=t(d)%*%temp%*%d
W
# 58.39632
1-pchisq(W,7)
# 3.152663e-10

# simulate data under the null
# assume 'true' coefficients are equal to estimated except that coefficients of 
# qual.cat.4 to qual.cat.10 are equal to coiefficient of qual.cat.3

true.cfs=qual.cat.inc$coefficients
true.cfs[2:9]=true.cfs[6] # it does not matter which coefficient/category is used as the reference! 
se=summary(qual.cat.inc)$sigma
regressors=model.matrix(qual.cat.inc)
nsim=1000
n=nrow(train)
all.W=numeric(nsim)
for (i in 1:nsim){
  
  y=regressors%*%true.cfs + rnorm(n,0,1)*se
  lm=lm(y~regressors-1)
  d=R%*%lm$coefficients
  se2=(summary(lm)$sigma)^2
  X=model.matrix(lm)
  XtXi=solve(t(X)%*%X)
  temp=solve(se2*R%*%XtXi%*%t(R))
  W0=t(d)%*%temp%*%d
  all.W[i]=W0
}
summary(all.W) # simulation dependent
# Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
# 0.3533  4.2009  6.2934  6.9708  8.9932 31.3868
quantile(all.W,c(0.05,0.95)) # simulated quantiles
# 5%       95% 
# 2.152732 13.821864 
c(qchisq(0.05,7),qchisq(0.95,7)) # theoretical/exact quantiles
# 2.16735 14.06714
mean(all.W>W[1])
# 0

