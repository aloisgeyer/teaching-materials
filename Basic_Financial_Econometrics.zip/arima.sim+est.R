# simulate&estimate ARMA models

n=500
phi1=0.95
phi2=-0.1

# simulate  AR(2)
ar2.sim<-arima.sim(model=list(ar=c(phi1,phi2)),n)
ts.plot(ar2.sim)
acf(ar2.sim,type="correlation",plot=T)
acf(ar2.sim,type="partial",plot=T) 

# estimate AR(1)
ar1.est=arima(ar2.sim, order = c(1, 0, 0), include.mean = FALSE)
ar1.est
e.ar1=residuals(ar1.est)
acf(e.ar1,type="correlation",plot=T)
acf(e.ar1,type="partial",plot=T)

# estimate AR(2)
ar2.est=arima(ar2.sim, order = c(2, 0, 0), include.mean = FALSE)
ar2.est
e.ar2=residuals(ar2.est)
acf(e.ar2,type="correlation",plot=T)
acf(e.ar2,type="partial",plot=T)

# estimate ARMA(1,1)
arma1.est=arima(ar2.sim, order = c(1, 0, 1), include.mean = FALSE)
arma1.est
e.arma1=residuals(arma1.est)
acf(e.arma1,type="correlation",plot=T)
acf(e.arma1,type="partial",plot=T)

# simulate  ARIMA(1,1,0)
arima110.sim<-arima.sim(model=list(ar=phi1,order=c(1,1,0)),n)
ts.plot(arima110.sim)
acf(arima110.sim,type="correlation",plot=T)
acf(arima110.sim,type="partial",plot=T) 

acf(diff(arima110.sim),type="correlation",plot=T)
acf(diff(arima110.sim),type="partial",plot=T) 
