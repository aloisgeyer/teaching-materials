library(dynlm)
library(AER)

coen <- read.csv("coen.txt",sep="",stringsAsFactors = FALSE)

coen=ts(coen, start=c(1948,1), end=c(1966,4), frequency=4)
coen=na.omit(coen)

reg.spx <- dynlm(FTX ~ SPX, data = coen)
summary(reg.spx)
plot(coen[,"FTX"])
points(reg.spx$fitted.values,col="red")
plot(reg.spx$residuals)
points(reg.spx$residuals)
acf(reg.spx$residuals)

# regression eqn used by Coen et al
reg <- dynlm(FTX ~ L(CAR,6) + L(FTCX,7), data = coen)
plot(coen[,"FTX"])
points(reg$fitted.values,col="red")
summary(reg)
plot(reg$residuals)
points(reg$residuals)
acf(reg$residuals)

# Newey-West corrected standard errors
coeftest(reg, vcov = NeweyWest(reg))

# account for autocorrelation of residuals by using partial differences
e=reg$residuals
reg.e=dynlm(e~L(e,1))
summary(reg.e)
rho=reg.e$coefficients[2]
reg.pd <- dynlm((FTX-L(rho*FTX,1)) ~ L((CAR-L(rho*CAR,1)),6) + L((FTCX-L(rho*FTCX,1)),7), data = coen)
summary(reg.pd)
acf(reg.pd$residuals)

# account for autocorrelation of residuals by adding the lagged dependent variable
reg.ldv <- dynlm(FTX ~ L(FTX, 1) + L(CAR,6) + L(FTCX,7), data = coen)
summary(reg.ldv)
acf(reg.ldv$residuals)

# account for autocorrelation of residuals by using differences
reg.d <- dynlm(diff(FTX) ~ L(diff(CAR),6) + L(diff(FTCX),7), data = coen)
summary(reg.d)
acf(reg.d$residuals)
    
# account for autocorrelation of residuals by using log returns 
reg.r <- dynlm(diff(log(FTX)) ~ L(diff(log(CAR)),6) + L(diff(log(FTCX)),7), data = coen)
summary(reg.r)
acf(reg.r$residuals)

library(tseries)

# unit root tests
adf.test(coen[,"FTX"])
adf.test(coen[,"SPX"])
adf.test(coen[,"CAR"])
adf.test(coen[,"GSX"])
adf.test(coen[,"RCX"])
adf.test(coen[,"FTCX"])
