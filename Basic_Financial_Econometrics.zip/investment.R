invest <- read.csv("investment.csv",header=T,sep=",") 

reg=lm(investment~GNP+interest+inflation,data=invest)

summary(reg)

invest[,"e"]=reg$residuals
invest[,"yhat"]=reg$fitted.values

se=sd(invest[,"e"])
sy=sd(invest[,"investment"])
syhat=sd(invest[,"yhat"])

# variance decomposition
print(se^2+syhat^2)
print(sy^2)

# R-squared
print(1-se^2/sy^2)

   
   