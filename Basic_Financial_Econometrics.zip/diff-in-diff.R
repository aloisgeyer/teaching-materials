# diff-in-diff.R

incin <- read.csv("diff-in-diff.txt",sep="",stringsAsFactors = FALSE)

reg <- lm(rprice ~ nearinc + y81+ nearinc*y81, data = incin)
summary(reg)

reg.controls <- lm(rprice ~ nearinc + y81 + nearinc*y81 + age + agesq + intst + land + area + rooms + baths, data = incin)
summary(reg.controls)