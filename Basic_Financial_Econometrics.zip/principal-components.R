# principal-components.R
# a simple example of a principal-components analysis

train <- read.csv("train.csv",stringsAsFactors = FALSE)

# pick some variables
x.vars=c("OverallQual","OverallCond","YearBuilt","TotRms")

cat("\n","correlations:","\n")
cor(train[,x.vars])

# based on 'prcomp' 

pc=prcomp(train[,x.vars],center = T,scale. = T) # setting center and scale TRUE makes sure to analyze correlations
summary(pc)

cat("\n","standardized loadings (eigenvectors):","\n")
pc$rotation
eigenvalues=pc$sdev^2;
cat("\n","eigenvalues:",eigenvalues,"\n")

cat("\n","principal components (scores):","\n")
head(pc$x)
tail(pc$x)

cat("\n","correlation among scores (must be an identity matrix):","\n")
cor(pc$x)

cat("\n","correlation between scores and raw data:","\n")
cat("\n","upper right (lower left) block corresponds to unstandardized loadings:","\n")
cor(cbind(pc$x,train[,x.vars]))

# based on 'princomp' 

prnc=princomp(train[,x.vars],cor = T)
summary(prnc)

cat("\n","standardized loadings (eigenvectors):","\n")
prnc$loadings
eigenvalues=prnc$sdev^2;
cat("\n","eigenvalues:",eigenvalues,"\n")

cat("\n","principal components (scores):","\n")
head(prnc$scores)
tail(prnc$scores)

cat("\n","correlation among scores (must be an identity matrix):","\n")
cor(prnc$scores)

cat("\n","correlation between scores and raw data:","\n")
cat("\n","upper right (lower left) block corresponds to unstandardized loadings:","\n")
cor(cbind(prnc$scores,train[,x.vars]))
